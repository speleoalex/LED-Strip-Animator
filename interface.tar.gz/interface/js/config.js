var config = {
lang:"it",
totalTime:0
};
