#include <Arduino.h>

extern HardwareSerial Serial;

void setup() {

}

void loop() {

}